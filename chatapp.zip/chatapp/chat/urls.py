from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),  # Add this line
]
urlpatterns = [
    path('', views.index, name='index'),
    path('task/', views.task_view, name='task'),  # Add this line
]
urlpatterns = [
    path('task/', views.task_view, name='task'),
]

urlpatterns = [
    path('', views.index, name='index'),
    path('chat/<str:username>/', views.chat_room, name='chat_room'),
    path('<str:username>/', views.chat_room, name='chat_room'),
]
