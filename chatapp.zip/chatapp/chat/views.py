# Create your views here.
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import Message
from django.shortcuts import get_object_or_404
@login_required  # This ensures only logged-in users can access this view
def index(request):
    users = User.objects.exclude(username=request.user.username)  # Fetch all users except the logged-in user
    messages = Message.objects.filter(sender=request.user) | Message.objects.filter(receiver=request.user)
    messages = messages.order_by('timestamp')
    return render(request, 'chat/index.html', {'users': users, 'messages': messages})
def task_view(request):
    return render(request, 'chat/Task.html')


from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'chat/signup.html', {'form': form})
@login_required
def index(request):
    users = User.objects.exclude(username=request.user.username)  # List other users
    return render(request, 'chat/index.html', {'users': users})

@login_required
def chat_room(request, username):
    other_user = User.objects.get(username=username)
    messages = Message.objects.filter(sender=request.user, receiver=other_user) | \
               Message.objects.filter(sender=other_user, receiver=request.user)
    messages = messages.order_by('timestamp')
    return render(request, 'chat/chat_room.html', {'other_user': other_user, 'messages': messages})
def chat_room(request, username):
    # Use get_object_or_404 to handle non-existent users gracefully
    other_user = get_object_or_404(User, username=username)

    # Remaining logic for the chat room
    return render(request, 'chat/chat_room.html', {'other_user': other_user})