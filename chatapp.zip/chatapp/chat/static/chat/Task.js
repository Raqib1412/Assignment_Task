// Collapsible Left Menu
const menuToggle = document.getElementById('menuToggle');
const leftMenu = document.getElementById('leftMenu');

menuToggle.addEventListener('click', () => {
    leftMenu.classList.toggle('hidden');
    const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', !isExpanded);
});

// Adjust Page Width Based on Screen Size
function adjustPageWidth() {
    const screenWidth = window.innerWidth;
    const container = document.querySelector('.container');

    if (screenWidth >= 992 && screenWidth <= 1600) {
        container.style.transform = 'scale(0.9)';
    } else if (screenWidth >= 700 && screenWidth < 767) {
        container.style.transform = 'scale(0.8)';
    } else if (screenWidth >= 600 && screenWidth < 700) {
        container.style.transform = 'scale(0.75)';
    } else if (screenWidth <= 600) {
        container.style.transform = 'scale(0.5)';
    } else {
        container.style.transform = 'scale(1)';
    }
}

// Call adjustPageWidth on load and resize
window.addEventListener('load', adjustPageWidth);
window.addEventListener('resize', adjustPageWidth);
